# PHP - PDO + MVC
Ejemplo en PHP con el paradigma orientado a objetos
## Descripción
Sistema de agenda de clientes desarrollado en PHP utilizando la librería Datatables para el manejo de datos.

## Frameworks utilizados
* [Datatables](https://datatables.net/) - Tablas dinámicas de datos
* [Bootstrap](http://getbootstrap.com/) - Bootstrap Library for frontend design

## Authors
* **Miguel Vega** - *Universidad Científica del Sur* 
* **Victor Sotomayor** - *Universidad Científica del Sur*